# AccessAble — Accessible Reading Website

## Run it
1. Extract the ZIP file.
2. Open `index.html` in a modern browser (Chrome or Edge recommended).
3. No build step, installation, API key, or server is required.

## Features
- Browser text-to-speech with play, pause/resume, stop, available voice selection, and speed control
- Live reading preview
- Font size, line spacing, font style, and light/dark/high-contrast/warm themes
- Focus reading mode
- Word count, character count, and estimated reading time
- Copy, clear, save, and restore text
- Local preference persistence
- Responsive layout and keyboard focus indicators

## Notes
- Text-to-speech availability and voices depend on the browser and operating system.
- Google Fonts are optional; the page uses system fallbacks if the internet is unavailable.
- This is a hackathon-ready front-end prototype, not a certified WCAG audit or medical/assistive-device replacement.
